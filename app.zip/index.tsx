import React, { useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import {
  BookOpen,
  Feather,
  Map as MapIcon,
  Scroll,
  Sword,
  Gem,
  Ghost,
  Mail,
  Menu,
  X,
  ChevronRight,
  ChevronLeft,
  Youtube,
  Twitter,
  Instagram,
  Facebook,
  Play
} from "lucide-react";

// --- Types ---
interface NewsItem {
  id: number;
  title: string;
  date: string;
  category: string;
  image: string;
  description: string;
}

interface Book {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  cover: string;
  status: "Published" | "Pre-Order" | "Writing";
  link: string;
}

// --- Data ---
const BOOKS: Book[] = [
  {
    id: 1,
    title: "Shadows of Aethelgard",
    subtitle: "Book One",
    description: "The crown was never meant for her. But when the shadows whispered her name, Elara had no choice but to listen. An epic tale of betrayal and dark magic.",
    cover: "https://images.unsplash.com/photo-1531988042231-d39a9cc12a9a?auto=format&fit=crop&q=80&w=600",
    status: "Published",
    link: "#"
  },
  {
    id: 2,
    title: "The Gilded Cage",
    subtitle: "Book Two",
    description: "Trapped in the glittering court of the Fae, alliances are forged in blood. The cost of freedom might be the very soul she swore to protect.",
    cover: "https://images.unsplash.com/photo-1515549832467-8783363e19b6?auto=format&fit=crop&q=80&w=600",
    status: "Published",
    link: "#"
  },
  {
    id: 3,
    title: "Crown of Ash",
    subtitle: "Book Three",
    description: "War has come to Aethelgard. As the ancient gods awaken, Elara must decide if she will be a savior or a conqueror.",
    cover: "https://images.unsplash.com/photo-1629196911514-cfd8d63f5e90?auto=format&fit=crop&q=80&w=600",
    status: "Pre-Order",
    link: "#"
  },
];

const NEWS: NewsItem[] = [
  {
    id: 1,
    title: "Cover Reveal: Crown of Ash",
    date: "Feb 05, 2026",
    category: "Announcement",
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=800",
    description: "The wait is over. Behold the final chapter of the Umbral Court saga."
  },
  {
    id: 2,
    title: "Winter Signing Tour Dates",
    date: "Jan 28, 2026",
    category: "Events",
    image: "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&q=80&w=800",
    description: "I'll be visiting London, New York, and Paris this winter!"
  },
  {
    id: 3,
    title: "Q&A: The Magic System",
    date: "Jan 15, 2026",
    category: "Lore",
    image: "https://images.unsplash.com/photo-1514894780887-121968d00567?auto=format&fit=crop&q=80&w=800",
    description: "Deep diving into how weaving works in the second age."
  },
];

const LORE_CARDS = [
  { icon: <MapIcon size={32} />, title: "The Map", desc: "Explore the fractured realms of Aethelgard and the Shadow Lands." },
  { icon: <Scroll size={32} />, title: "History", desc: "Three thousand years of dynasty, war, and fallen gods." },
  { icon: <Gem size={32} />, title: "Magic", desc: "The elemental weaving system that binds the world together." },
  { icon: <Sword size={32} />, title: "Armory", desc: "Legendary weapons forged in star-fire and void-glass." },
  { icon: <Ghost size={32} />, title: "Bestiary", desc: "Creatures of the night that stalk the forbidden forests." },
  { icon: <BookOpen size={32} />, title: "Grimoire", desc: "Ancient spells forbidden by the High Council." },
];

// --- Styles ---
const styles = `
  :root {
    --color-bg: #050505;
    --color-bg-light: #0f1420;
    --color-primary: #C5A059;
    --color-primary-hover: #E5C079;
    --color-text: #e0e0e0;
    --color-text-muted: #8a9bb5;
    --color-accent: #1e283d;
  }

  * {
    box-sizing: border-box;
  }

  body {
    font-family: 'Lato', sans-serif;
    background-color: var(--color-bg);
    color: var(--color-text);
    overflow-x: hidden;
  }

  h1, h2, h3, h4, h5, h6 {
    font-family: 'Playfair Display', serif;
    margin: 0;
  }

  .font-cinzel {
    font-family: 'Cinzel', serif;
  }

  /* Animations */
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
  }

  @keyframes shimmer {
    0% { background-position: -100% 0; }
    100% { background-position: 100% 0; }
  }

  .animate-fade-up {
    animation: fadeUp 1s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  }

  .animate-delay-100 { animation-delay: 0.1s; }
  .animate-delay-200 { animation-delay: 0.2s; }
  .animate-delay-300 { animation-delay: 0.3s; }

  /* Utility */
  .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 12px 28px;
    font-family: 'Cinzel', serif;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    transition: all 0.3s ease;
    cursor: pointer;
    text-decoration: none;
    border: 1px solid var(--color-primary);
  }

  .btn-primary {
    background: linear-gradient(45deg, #a67c00, #C5A059);
    color: #000;
    border: none;
  }

  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px -5px rgba(197, 160, 89, 0.4);
  }

  .btn-outline {
    background: transparent;
    color: var(--color-primary);
  }

  .btn-outline:hover {
    background: rgba(197, 160, 89, 0.1);
    color: #fff;
  }

  .section-heading {
    text-align: center;
    margin-bottom: 60px;
    position: relative;
  }

  .section-heading h2 {
    font-size: 3rem;
    color: var(--color-primary);
    margin-bottom: 10px;
  }

  .section-heading .decoration {
    display: block;
    width: 100px;
    height: 2px;
    background: linear-gradient(90deg, transparent, var(--color-primary), transparent);
    margin: 10px auto;
  }

  /* Custom Scrollbar */
  ::-webkit-scrollbar {
    width: 8px;
  }
  ::-webkit-scrollbar-track {
    background: #000;
  }
  ::-webkit-scrollbar-thumb {
    background: #333;
    border-radius: 4px;
  }
  ::-webkit-scrollbar-thumb:hover {
    background: var(--color-primary);
  }
`;

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        transition: "all 0.4s ease",
        background: isScrolled ? "rgba(5, 5, 5, 0.95)" : "linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)",
        padding: isScrolled ? "15px 0" : "30px 0",
        borderBottom: isScrolled ? "1px solid rgba(197, 160, 89, 0.1)" : "none",
        backdropFilter: isScrolled ? "blur(10px)" : "none",
      }}
    >
      <div className="container" style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
          <a href="#" style={{ fontFamily: "Cinzel", fontSize: "2rem", fontWeight: "bold", color: "#fff", textDecoration: "none", letterSpacing: "2px" }}>
            E.V.
          </a>
          <div style={{ width: "1px", height: "30px", background: "rgba(255,255,255,0.2)" }} className="hidden-mobile" />
          <div className="hidden-mobile" style={{ display: "flex", gap: "20px" }}>
             {/* Progress Indicators (adapted from Server Status) */}
            <StatusIndicator title="Shadows" status="Published" color="#4ade80" />
            <StatusIndicator title="Gilded" status="Published" color="#4ade80" />
            <StatusIndicator title="Ash" status="Editing 85%" color="#fbbf24" />
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden-mobile" style={{ display: "flex", gap: "30px", alignItems: "center" }}>
          {["Home", "The Saga", "World", "News", "Shop"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(" ", "-")}`}
              style={{ color: "#e0e0e0", textDecoration: "none", textTransform: "uppercase", fontSize: "0.85rem", letterSpacing: "1px", fontWeight: 600, transition: "color 0.2s" }}
              onMouseOver={(e) => (e.currentTarget.style.color = "#C5A059")}
              onMouseOut={(e) => (e.currentTarget.style.color = "#e0e0e0")}
            >
              {item}
            </a>
          ))}
          <a href="#newsletter" className="btn btn-primary" style={{ padding: "8px 20px", fontSize: "0.8rem" }}>
            Join the Guild
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="visible-mobile"
          style={{ background: "none", border: "none", color: "#fff", cursor: "pointer", display: "none" }}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div style={{
          position: "fixed",
          top: "60px",
          left: 0,
          right: 0,
          background: "#050505",
          padding: "20px",
          borderBottom: "1px solid #333",
          display: "flex",
          flexDirection: "column",
          gap: "15px",
          alignItems: "center"
        }}>
          {["Home", "The Saga", "World", "News", "Shop"].map((item) => (
            <a key={item} href="#" style={{ color: "#fff", textDecoration: "none", fontSize: "1.1rem" }}>{item}</a>
          ))}
        </div>
      )}
      
      <style>{`
        @media (max-width: 992px) {
          .hidden-mobile { display: none !important; }
          .visible-mobile { display: block !important; }
        }
      `}</style>
    </nav>
  );
};

const StatusIndicator = ({ title, status, color }: { title: string; status: string; color: string }) => (
  <div style={{ display: "flex", alignItems: "center", gap: "10px", background: "rgba(255,255,255,0.05)", padding: "5px 12px", borderRadius: "20px", border: "1px solid rgba(255,255,255,0.1)" }}>
    <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: color, boxShadow: `0 0 10px ${color}` }}></div>
    <div style={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
      <span style={{ fontSize: "0.65rem", color: "#8a9bb5", textTransform: "uppercase" }}>{title}</span>
      <span style={{ fontSize: "0.75rem", fontWeight: "bold", color: color }}>{status}</span>
    </div>
  </div>
);

const Hero = () => {
  return (
    <section id="home" style={{ position: "relative", height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
      {/* Background Image with Overlay */}
      <div style={{
        position: "absolute",
        top: 0, left: 0, right: 0, bottom: 0,
        backgroundImage: "url('https://images.unsplash.com/photo-1519074069444-1ba4fff66d16?auto=format&fit=crop&q=80&w=2000')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        filter: "brightness(0.4) saturate(0.8)"
      }}></div>
      
      {/* Cinematic Gradient Overlay */}
      <div style={{
        position: "absolute",
        top: 0, left: 0, right: 0, bottom: 0,
        background: "radial-gradient(circle at center, transparent 0%, #050505 90%)"
      }}></div>

      {/* Content */}
      <div className="container" style={{ position: "relative", zIndex: 10, textAlign: "center", maxWidth: "800px" }}>
        <div className="animate-fade-up">
          <p style={{
            fontFamily: "Cinzel",
            color: "#C5A059",
            letterSpacing: "4px",
            textTransform: "uppercase",
            marginBottom: "20px",
            fontSize: "1.1rem"
          }}>The New York Times Bestselling Series</p>
          
          <h1 style={{
            fontSize: "clamp(3rem, 8vw, 6rem)",
            color: "#fff",
            lineHeight: 0.9,
            marginBottom: "30px",
            textShadow: "0 10px 30px rgba(0,0,0,0.5)"
          }}>
            The Umbral <br /> <span style={{ fontFamily: "Playfair Display", fontStyle: "italic", color: "#C5A059" }}>Court</span>
          </h1>
          
          <p style={{
            fontSize: "1.2rem",
            color: "#cbd5e1",
            marginBottom: "50px",
            lineHeight: 1.6,
            maxWidth: "600px",
            marginLeft: "auto",
            marginRight: "auto"
          }}>
            Enter a world where shadows bargain for souls and the crown is forged in blood. The epic conclusion arrives this winter.
          </p>

          <div style={{ display: "flex", gap: "20px", justifyContent: "center", flexWrap: "wrap" }}>
            <a href="#" className="btn btn-primary">
              <BookOpen size={20} style={{ marginRight: "10px" }} />
              Read Chapter One
            </a>
            <a href="#" className="btn btn-outline" style={{ borderColor: "#fff", color: "#fff" }}>
              <Play size={20} style={{ marginRight: "10px" }} />
              Watch Trailer
            </a>
          </div>
        </div>
      </div>
      
      {/* Bottom Fade */}
      <div style={{
        position: "absolute",
        bottom: 0, left: 0, right: 0, height: "150px",
        background: "linear-gradient(to top, #050505, transparent)"
      }}></div>
    </section>
  );
};

const NewsSection = () => {
  return (
    <section id="news" style={{ padding: "100px 0", background: "#050505" }}>
      <div className="container">
        <div className="section-heading animate-fade-up">
          <span style={{ fontFamily: "Cinzel", color: "#8a9bb5", letterSpacing: "2px" }}>The Chronicle</span>
          <h2>Latest News</h2>
          <span className="decoration"></span>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "40px" }}>
          {/* Main Feature */}
          <div className="animate-fade-up" style={{ gridColumn: "span 1" }}>
             <a href="#" style={{ display: "block", textDecoration: "none", color: "inherit", height: "100%" }}>
              <div style={{ 
                position: "relative", 
                borderRadius: "4px", 
                overflow: "hidden", 
                height: "100%", 
                background: "#0f1420", 
                border: "1px solid #1e283d",
                transition: "transform 0.3s ease",
              }}
              onMouseOver={(e) => e.currentTarget.style.transform = "translateY(-5px)"}
              onMouseOut={(e) => e.currentTarget.style.transform = "translateY(0)"}
              >
                <div style={{ position: "relative", height: "300px", overflow: "hidden" }}>
                  <img 
                    src={NEWS[0].image} 
                    alt={NEWS[0].title}
                    style={{ width: "100%", height: "100%", objectFit: "cover" }}
                  />
                  <div style={{ 
                    position: "absolute", 
                    top: "20px", 
                    left: "20px", 
                    background: "#C5A059", 
                    color: "#000", 
                    padding: "4px 12px", 
                    fontFamily: "Cinzel", 
                    fontSize: "0.8rem", 
                    fontWeight: "bold",
                    textTransform: "uppercase"
                  }}>
                    {NEWS[0].category}
                  </div>
                </div>
                <div style={{ padding: "30px" }}>
                  <div style={{ color: "#8a9bb5", fontSize: "0.9rem", marginBottom: "10px", display: "flex", justifyContent: "space-between" }}>
                    <span>{NEWS[0].date}</span>
                    <span style={{ color: "#C5A059" }}>By Elena</span>
                  </div>
                  <h3 style={{ fontSize: "1.8rem", marginBottom: "15px", color: "#fff" }}>{NEWS[0].title}</h3>
                  <p style={{ color: "#8a9bb5", lineHeight: 1.6 }}>{NEWS[0].description}</p>
                  <span style={{ display: "inline-block", marginTop: "20px", color: "#C5A059", borderBottom: "1px solid #C5A059", paddingBottom: "2px", fontSize: "0.9rem", textTransform: "uppercase", letterSpacing: "1px" }}>Read Full Article</span>
                </div>
              </div>
             </a>
          </div>

          {/* Side List */}
          <div style={{ display: "flex", flexDirection: "column", gap: "20px", gridColumn: "span 1" }}>
             {NEWS.slice(1).map((news, idx) => (
               <a key={news.id} href="#" className={`animate-fade-up animate-delay-${(idx + 1) * 100}`} style={{ textDecoration: "none" }}>
                 <div style={{ 
                   display: "flex", 
                   gap: "20px", 
                   background: "#0f1420", 
                   border: "1px solid #1e283d", 
                   padding: "20px",
                   borderRadius: "4px",
                   alignItems: "center",
                   transition: "border-color 0.3s"
                 }}
                 onMouseOver={(e) => e.currentTarget.style.borderColor = "#C5A059"}
                 onMouseOut={(e) => e.currentTarget.style.borderColor = "#1e283d"}
                 >
                   <div style={{ width: "100px", height: "100px", flexShrink: 0, borderRadius: "4px", overflow: "hidden" }}>
                     <img src={news.image} alt={news.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                   </div>
                   <div>
                     <div style={{ fontSize: "0.8rem", color: "#C5A059", marginBottom: "5px", textTransform: "uppercase" }}>{news.category}</div>
                     <h4 style={{ color: "#fff", fontSize: "1.2rem", marginBottom: "8px" }}>{news.title}</h4>
                     <div style={{ color: "#64748b", fontSize: "0.85rem" }}>{news.date}</div>
                   </div>
                 </div>
               </a>
             ))}
             
             {/* Newsletter Mini Card */}
             <div className="animate-fade-up animate-delay-300" style={{ 
               background: "linear-gradient(135deg, #1e283d 0%, #0f1420 100%)", 
               padding: "30px", 
               borderRadius: "4px", 
               border: "1px solid #C5A059",
               textAlign: "center",
               marginTop: "auto"
             }}>
               <Mail size={32} color="#C5A059" style={{ marginBottom: "15px" }} />
               <h3 style={{ color: "#fff", marginBottom: "10px" }}>Join the Inner Circle</h3>
               <p style={{ color: "#8a9bb5", fontSize: "0.9rem", marginBottom: "20px" }}>Get exclusive prequel chapters when you sign up.</p>
               <input type="email" placeholder="Your email address" style={{ 
                 width: "100%", 
                 padding: "12px", 
                 background: "rgba(0,0,0,0.3)", 
                 border: "1px solid #333", 
                 color: "#fff", 
                 marginBottom: "10px",
                 borderRadius: "2px"
               }} />
               <button className="btn btn-primary" style={{ width: "100%" }}>Subscribe</button>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const LoreSection = () => {
  return (
    <section id="world" style={{ padding: "100px 0", background: "#080a0f", borderTop: "1px solid #1e283d" }}>
      <div className="container">
        <div className="section-heading animate-fade-up">
          <span style={{ fontFamily: "Cinzel", color: "#8a9bb5", letterSpacing: "2px" }}>Immersion</span>
          <h2>Enter the Realm</h2>
          <span className="decoration"></span>
          <p style={{ maxWidth: "700px", margin: "0 auto", color: "#8a9bb5", lineHeight: 1.6 }}>
            Aethelgard is a land of ancient scars, where the Veil between worlds is thin and the Old Gods sleep beneath the mountains.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "20px" }}>
          {LORE_CARDS.map((item, idx) => (
            <div key={idx} className="animate-fade-up" style={{ animationDelay: `${idx * 0.1}s` }}>
              <div style={{ 
                background: "#0f1420", 
                padding: "30px", 
                borderRadius: "4px", 
                border: "1px solid #1e283d",
                display: "flex",
                alignItems: "flex-start",
                gap: "20px",
                transition: "all 0.3s ease",
                cursor: "pointer",
                height: "100%"
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = "translateY(-5px)";
                e.currentTarget.style.borderColor = "#C5A059";
                const icon = e.currentTarget.querySelector('.icon-wrapper') as HTMLElement;
                if(icon) icon.style.color = "#C5A059";
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.borderColor = "#1e283d";
                const icon = e.currentTarget.querySelector('.icon-wrapper') as HTMLElement;
                if(icon) icon.style.color = "#475569";
              }}
              >
                <div className="icon-wrapper" style={{ color: "#475569", transition: "color 0.3s" }}>
                  {item.icon}
                </div>
                <div>
                  <h3 style={{ color: "#fff", fontSize: "1.2rem", marginBottom: "8px" }}>{item.title}</h3>
                  <p style={{ color: "#8a9bb5", fontSize: "0.9rem", lineHeight: 1.5, margin: 0 }}>{item.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const BookShowcase = () => {
  const [activeBook, setActiveBook] = useState(BOOKS[0]);

  return (
    <section id="the-saga" style={{ 
      padding: "100px 0", 
      background: "url('https://images.unsplash.com/photo-1598555845941-073dbb9308cc?auto=format&fit=crop&q=80&w=2000') no-repeat center center/cover",
      position: "relative"
    }}>
      <div style={{ position: "absolute", inset: 0, background: "rgba(5, 5, 5, 0.9)" }}></div>
      
      <div className="container" style={{ position: "relative", zIndex: 2 }}>
        <div className="section-heading animate-fade-up">
           <span style={{ fontFamily: "Cinzel", color: "#C5A059", letterSpacing: "2px" }}>The Saga</span>
           <h2 style={{ color: "#fff" }}>The Books</h2>
           <span className="decoration"></span>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "60px" }}>
          {/* Main Active Book Display */}
          <div className="animate-fade-up" style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(350px, 1fr))", 
            gap: "50px", 
            alignItems: "center" 
          }}>
            {/* Cover */}
            <div style={{ position: "relative", maxWidth: "400px", margin: "0 auto" }}>
              <div style={{ 
                position: "absolute", 
                top: "20px", 
                left: "20px", 
                right: "-20px", 
                bottom: "-20px", 
                border: "1px solid #C5A059", 
                zIndex: 0 
              }}></div>
              <img 
                src={activeBook.cover} 
                alt={activeBook.title}
                style={{ 
                  width: "100%", 
                  borderRadius: "2px", 
                  boxShadow: "0 20px 50px rgba(0,0,0,0.5)", 
                  position: "relative", 
                  zIndex: 1,
                  display: "block"
                }} 
              />
            </div>

            {/* Info */}
            <div>
              <div style={{ color: "#C5A059", fontSize: "1.2rem", fontFamily: "Cinzel", marginBottom: "10px" }}>{activeBook.subtitle}</div>
              <h3 style={{ fontSize: "3.5rem", color: "#fff", lineHeight: 1.1, marginBottom: "30px" }}>{activeBook.title}</h3>
              <p style={{ color: "#cbd5e1", fontSize: "1.1rem", lineHeight: 1.8, marginBottom: "40px" }}>{activeBook.description}</p>
              <div style={{ display: "flex", gap: "20px", alignItems: "center" }}>
                <a href={activeBook.link} className="btn btn-primary">Purchase Now</a>
                <span style={{ color: "#fff", fontSize: "0.9rem", opacity: 0.7 }}>Available in Hardcover, E-book & Audio</span>
              </div>
            </div>
          </div>

          {/* Book Selector */}
          <div style={{ display: "flex", justifyContent: "center", gap: "30px", flexWrap: "wrap", marginTop: "40px" }}>
            {BOOKS.map((book) => (
              <div 
                key={book.id} 
                onClick={() => setActiveBook(book)}
                style={{ 
                  cursor: "pointer", 
                  opacity: activeBook.id === book.id ? 1 : 0.5,
                  transform: activeBook.id === book.id ? "scale(1.05)" : "scale(1)",
                  transition: "all 0.3s ease",
                  textAlign: "center"
                }}
              >
                <img 
                  src={book.cover} 
                  alt={book.title} 
                  style={{ width: "100px", height: "150px", objectFit: "cover", boxShadow: "0 5px 15px rgba(0,0,0,0.3)", marginBottom: "10px" }}
                />
                <div style={{ fontSize: "0.8rem", color: "#fff", maxWidth: "100px", margin: "0 auto" }}>{book.title}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const MediaSection = () => {
  return (
    <section id="media" style={{ padding: "100px 0", background: "#050505" }}>
      <div className="container">
        <div className="section-heading animate-fade-up">
           <span style={{ fontFamily: "Cinzel", color: "#8a9bb5", letterSpacing: "2px" }}>The Archives</span>
           <h2>Visual Media</h2>
           <span className="decoration"></span>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "30px" }}>
           {[1, 2, 3, 4].map((item) => (
             <div key={item} className="animate-fade-up" style={{ position: "relative", aspectRatio: "16/9", background: "#111", border: "1px solid #333", borderRadius: "4px", overflow: "hidden", cursor: "pointer" }}>
                <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", zIndex: 2 }}>
                  <div style={{ width: "60px", height: "60px", background: "rgba(197, 160, 89, 0.9)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", transition: "transform 0.2s" }}>
                    <Play fill="#000" size={24} />
                  </div>
                </div>
                <img 
                  src={`https://images.unsplash.com/photo-${item === 1 ? '1626245353457-418df45610e7' : item === 2 ? '1535905557558-afc4877a26fc' : '1514539079130-2595032f0563'}?auto=format&fit=crop&q=80&w=600`} 
                  alt="Video thumbnail"
                  style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.6, transition: "opacity 0.3s" }} 
                />
             </div>
           ))}
        </div>
        
        <div style={{ textAlign: "center", marginTop: "50px" }}>
          <a href="#" className="btn btn-outline">Visit YouTube Channel</a>
        </div>
      </div>
    </section>
  );
}

const Footer = () => {
  return (
    <footer style={{ background: "#020202", borderTop: "1px solid #111", padding: "80px 0 30px" }}>
      <div className="container">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "50px", marginBottom: "60px" }}>
          
          {/* Brand */}
          <div style={{ textAlign: "center" }}>
            <h2 style={{ fontFamily: "Cinzel", fontSize: "2.5rem", color: "#fff", marginBottom: "20px" }}>E.V.</h2>
            <p style={{ color: "#64748b", lineHeight: 1.6, marginBottom: "30px" }}>
              Weaving worlds from shadow and starlight. Join me on a journey through the fractured realms.
            </p>
            <div style={{ display: "flex", justifyContent: "center", gap: "20px" }}>
              {[Twitter, Instagram, Facebook, Youtube].map((Icon, i) => (
                <a key={i} href="#" style={{ color: "#8a9bb5", transition: "color 0.2s" }} onMouseOver={(e) => e.currentTarget.style.color = "#C5A059"} onMouseOut={(e) => e.currentTarget.style.color = "#8a9bb5"}>
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div style={{ display: "flex", justifyContent: "center", gap: "60px" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
              <h4 style={{ color: "#C5A059", fontFamily: "Cinzel", marginBottom: "10px" }}>Explore</h4>
              <a href="#home" style={{ color: "#e0e0e0", textDecoration: "none" }}>Home</a>
              <a href="#books" style={{ color: "#e0e0e0", textDecoration: "none" }}>Books</a>
              <a href="#news" style={{ color: "#e0e0e0", textDecoration: "none" }}>News</a>
              <a href="#events" style={{ color: "#e0e0e0", textDecoration: "none" }}>Events</a>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
              <h4 style={{ color: "#C5A059", fontFamily: "Cinzel", marginBottom: "10px" }}>Support</h4>
              <a href="#" style={{ color: "#e0e0e0", textDecoration: "none" }}>Press Kit</a>
              <a href="#" style={{ color: "#e0e0e0", textDecoration: "none" }}>Contact</a>
              <a href="#" style={{ color: "#e0e0e0", textDecoration: "none" }}>Newsletter</a>
              <a href="#" style={{ color: "#e0e0e0", textDecoration: "none" }}>Privacy</a>
            </div>
          </div>

        </div>

        {/* Bottom */}
        <div style={{ borderTop: "1px solid #111", paddingTop: "30px", textAlign: "center", color: "#475569", fontSize: "0.85rem" }}>
          <p>&copy; 2026 Elena Vossen. All rights reserved. Site designed with stardust.</p>
        </div>
      </div>
    </footer>
  );
};

const App = () => {
  return (
    <>
      <style>{styles}</style>
      <Navbar />
      <Hero />
      <NewsSection />
      <LoreSection />
      <BookShowcase />
      <MediaSection />
      <Footer />
    </>
  );
};

const root = createRoot(document.getElementById("root")!);
root.render(<App />);
